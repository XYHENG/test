package com.haina.news.domin;

public class Mynews {
	private int id;
	private String title;
    private String content;
    private String source;
    private String zaiyao;
    private String url1;
    private String url2;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getZaiyao() {
		return zaiyao;
	}
	public void setZaiyao(String zaiyao) {
		this.zaiyao = zaiyao;
	}
	public String getUrl1() {
		return url1;
	}
	public void setUrl1(String url1) {
		this.url1 = url1;
	}
	public String getUrl2() {
		return url2;
	}
	public void setUrl2(String url2) {
		this.url2 = url2;
	}

    
    

}